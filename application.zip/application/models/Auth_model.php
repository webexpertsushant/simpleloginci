<?php
class Auth_model extends CI_Model{

    public function ___construct(){
        parent::___construct();
    }




    
}